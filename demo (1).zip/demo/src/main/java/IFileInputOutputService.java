import java.util.List;

public interface IFileInputOutputService {

    List<Users> getUsersFromFile(String filePath);

}