

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.DeleteMapping;

import java.util.Collections;
import java.util.List;

@RestController
@RequestMapping("/users")
public class Main{

    private List<Users> usersList;
    private List<Users> sorteduserList;

    public Main() {
        usersList = readCSV();
        sorteduserList = sortList();
    }

    private List<Users> readCSV() {
        int newCoverage = 1;
        IFileInputOutputService iservice = new FileInputOutputService();
        List<Users> usersFromFile = iservice.getUsersFromFile("src/hpv_2020s_results.csv");
        Collections.sort(usersFromFile);
        for (var user : usersFromFile) {
            user.setCoverage(newCoverage++);
        }
        return usersFromFile;
    }

    private List<Users> sortList() {
        Collections.sort(usersList);
        int newCoverage = 1;
        for (var user : usersList) {
            user.setCoverage(newCoverage++);
        }
        return usersList;
    }

    //GET endpoint to retrieve all games
    @GetMapping
    public List<Users> getAllUsers() {
        return usersList;
    }

    //GET endpoint to retrieve a specific game by id
    @GetMapping("/{endp1}")
    public Users getUsersbyCoverage(@PathVariable Integer Coverage) {
        return usersList.stream()
                .filter(users -> users.getCoverage().equals(Coverage))
                .findFirst()
                .orElse(null);
    }

    //add coverage
    @PostMapping("/{endp2}")
    public Users addCoverage(@RequestBody Users users) {
        usersList.add(users);
        return users;
    }

    //PUT endpoint to update an existing game's name
    @PutMapping("/{endp3}")
    public Users updateCoverage(@PathVariable Integer Coverage, @RequestBody Users updatedCoverage) {
        for (var users : usersList) {
            if (users.getCoverage().equals(Coverage)) {
                users.setCoverage(updatedCoverage.getCoverage());
                return users;
            }
        }
        return null; //user not found
    }

    //DELETE user
    @DeleteMapping("/{endp4}")
    public void deleteUsers(@PathVariable Integer Coverage) {
        usersList.removeIf(users -> users.getCoverage().equals(Coverage));
    }

}